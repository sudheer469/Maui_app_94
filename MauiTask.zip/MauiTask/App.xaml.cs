﻿using MauiTask.CustomControls;

namespace MauiTask
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            IOCConfiguration.ConfigureServices();
            //ConfigureHandlers();
            MainPage = !string.IsNullOrEmpty(Preferences.Get("UserName", "")) ? new AppShell() : new NavigationPage(new LoginView());
        }

        private static void ConfigureHandlers()
        {
#if ANDROID
            Microsoft.Maui.Handlers.EntryHandler.Mapper.AppendToMapping(nameof(BorderedEntry), (handler, view) =>
            {
                if (handler.PlatformView is AndroidX.AppCompat.Widget.AppCompatEditText nativeView)
                {
                    var borderColor = Android.Graphics.Color.ParseColor("#000000"); // Border color (blue)
                    int borderWidth = 4; // Border width

                    var shape = new Android.Graphics.Drawables.ShapeDrawable(new Android.Graphics.Drawables.Shapes.RectShape());
                    shape.Paint.Color = borderColor;
                    shape.Paint.StrokeWidth = borderWidth;
                    shape.Paint.SetStyle(Android.Graphics.Paint.Style.Stroke);

                    // Set the border properties
                    nativeView.Background = shape;
                    //nativeView.SetPadding(20, 20, 20, 20); // Set padding if needed
                }
            });

#elif IOS
            Microsoft.Maui.Handlers.EntryHandler.Mapper.AppendToMapping(nameof(BorderedEntry), (handler, view) =>
            {
                if (handler.PlatformView is Microsoft.Maui.Platform.MauiTextField nativeView)
                {
                    // Set the border properties
                    nativeView.Layer.BorderColor = UIKit.UIColor.FromRGB(0, 122, 255).CGColor; // Border color (blue)
                    nativeView.Layer.BorderWidth = 1; // Border width
                    nativeView.Layer.CornerRadius = 5; // Corner radius
                    nativeView.ClipsToBounds = true; // Clip content to bounds
                }
            });
#endif
        }
    }
}
