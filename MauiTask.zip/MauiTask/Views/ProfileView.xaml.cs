namespace MauiTask.Views;

public partial class ProfileView : ContentPage
{
    public ProfileView()
    {
		try
		{
            InitializeComponent();
            BindingContext = IOCConfiguration.ServiceProvider?.GetService<ProfileViewModel>();
        }
		catch (Exception ex)
		{

		}
    }
}