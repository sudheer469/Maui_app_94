using MauiTask.Bootstrap;
namespace MauiTask.Views;

public partial class LoginView : ContentPage
{
    public LoginView()
    {
        InitializeComponent();
        BindingContext = IOCConfiguration.ServiceProvider?.GetService<LoginViewModel>();
    }
}