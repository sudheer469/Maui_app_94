﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using MauiTask.Models;

namespace MauiTask.ViewModels
{
    public partial class LoginViewModel : ObservableObject
    {
        [ObservableProperty]
        private User user;

        public LoginViewModel()
        {
            User = new User();
        }

        [RelayCommand]
        public void Login()
        {
            Preferences.Set("NickName", User.NickName);
            Preferences.Set("UserName", User.UserName);
            Application.Current.MainPage = new AppShell();
        }
    }
}
