﻿
using CommunityToolkit.Mvvm.ComponentModel;

namespace MauiTask.ViewModels
{
    public partial class DetailsViewModel : ObservableObject
    {
        [ObservableProperty]
        private WebViewSource source;

        public DetailsViewModel()
        {
            // Define your HTML content
            string htmlContent = @"
                <html>
                <head>
                    <title>My HTML Page</title>
                </head>
                <body>
                    <h1>Hello, .NET MAUI!</h1>
                    <p>This is a paragraph of HTML content.</p>
                </body>
                </html>";

            // Load HTML content into WebView
            Source = new HtmlWebViewSource { Html = htmlContent };
        }
    }
}
