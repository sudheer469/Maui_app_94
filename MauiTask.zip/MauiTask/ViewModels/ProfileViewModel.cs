﻿using CommunityToolkit.Mvvm.Input;

namespace MauiTask.ViewModels
{
    public partial class ProfileViewModel
    {
        public ProfileViewModel()
        {
        }

        [RelayCommand]
        public async Task SaveAsync()
        {
            await Application.Current.MainPage.DisplayAlert("Save", "Profile saved", "Ok");
        }

        [RelayCommand]
        public void Logout()
        {
            Application.Current.MainPage = new NavigationPage(new LoginView());
            Preferences.Remove("UserName");
        }
    }
}
