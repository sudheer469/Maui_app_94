﻿using System.Text.RegularExpressions;

namespace MauiTask.Behaviors
{
    public class PasswordValidationBehavior : Behavior<Entry>
    {
        private const string PasswordPattern = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$";

        protected override void OnAttachedTo(Entry bindable)
        {
            base.OnAttachedTo(bindable);
            bindable.TextChanged += Bindable_TextChanged;
        }

        private void Bindable_TextChanged(object? sender, TextChangedEventArgs e)
        {
            if (sender is Entry entry)
            {
                entry.TextColor = IsValidPassword(entry.Text) ? Colors.Black : Colors.Red;
            }
        }

        protected override void OnDetachingFrom(Entry bindable)
        {
            base.OnDetachingFrom(bindable);
            bindable.TextChanged -= Bindable_TextChanged;
        }

        public static bool IsValidPassword(string password)
        {
            if (string.IsNullOrEmpty(password))
            {
                return false;
            }

            // Create a regex object with the pattern
            var regex = new Regex(PasswordPattern);

            // Check if the password matches the pattern
            return regex.IsMatch(password);
        }
    }
}
