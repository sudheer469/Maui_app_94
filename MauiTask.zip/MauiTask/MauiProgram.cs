﻿using CommunityToolkit.Maui;
using MauiTask.CustomControls;
using Microsoft.Extensions.Logging;
using Microsoft.Maui.Controls.Compatibility.Hosting;

namespace MauiTask
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .UseMauiCompatibility()
                .UseMauiCommunityToolkit()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                })
                .ConfigureMauiHandlers(handlers =>
                {
#if ANDROID
                    handlers.AddCompatibilityRenderer(typeof(BorderedEntry), typeof(Platforms.Android.CustomRenderers.BorderedEntryRenderer));
#elif IOS
                    handlers.AddCompatibilityRenderer(typeof(BorderedEntry), typeof(Platforms.iOS.CustomRenderers.BorderedEntryRenderer));
#endif
                });


#if DEBUG
            builder.Logging.AddDebug();
#endif

            return builder.Build();
        }
    }
}
