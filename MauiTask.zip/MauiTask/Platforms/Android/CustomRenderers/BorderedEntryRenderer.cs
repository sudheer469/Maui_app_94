﻿using Android.Content;
using Android.Graphics.Drawables;
using MauiTask.CustomControls;
using Microsoft.Maui.Controls.Compatibility.Platform.Android;
using Microsoft.Maui.Controls.Platform;
using Microsoft.Maui.Platform;

namespace MauiTask.Platforms.Android.CustomRenderers
{
    public class BorderedEntryRenderer : EntryRenderer
    {
        public BorderedEntryRenderer(Context context) : base(context)
        {
        }

        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);

            if (Control != null)
            {
                var entry = (BorderedEntry)e.NewElement;
                var borderColor = entry.BorderColor.ToPlatform();
                var borderWidth = (int)entry.BorderWidth;
                var cornerRadius = (int)entry.CornerRadius;

                var shape = new GradientDrawable();
                shape.SetShape(ShapeType.Rectangle);
                shape.SetStroke(borderWidth, borderColor);
                shape.SetCornerRadius(cornerRadius);

                Control.Background = shape;
            }
        }
    }
}
