﻿using MauiTask.CustomControls;
using Microsoft.Maui.Controls.Compatibility.Platform.iOS;
using Microsoft.Maui.Controls.Platform;
using Microsoft.Maui.Platform;

namespace MauiTask.Platforms.iOS.CustomRenderers
{
    public class BorderedEntryRenderer : EntryRenderer
    {
        public BorderedEntryRenderer()
        {
        }

        protected override void OnElementChanged(ElementChangedEventArgs<Entry> e)
        {
            base.OnElementChanged(e);

            if (Control != null)
            {
                var entry = (BorderedEntry)e.NewElement;

                Control.Layer.BorderColor = entry.BorderColor.ToPlatform().CGColor;
                Control.Layer.BorderWidth = (nfloat)entry.BorderWidth;
                Control.Layer.CornerRadius = (nfloat)entry.CornerRadius;
                Control.ClipsToBounds = true; // Ensure the border is clipped to the control
            }
        }
    }
}
